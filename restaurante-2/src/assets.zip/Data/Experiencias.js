export const experiencias = [
  {
    id: 1,
    titulo: "Camino del Sol",
    except: "Un recorrido por sabores tradicionales que honran la conexión entre la tierra y el Inti (sol). Incluye platos emblemáticos reinterpretados con técnicas modernas.",
  },
  {
    id: 2,
    titulo: "Sabores del Altiplano",
    except: "Una propuesta que reúne la riqueza de ingredientes de altura, como la quinua, la alpaca y tubérculos nativos. Ideal para quienes buscan una vivencia auténtica y ancestral.",
  },
  {
    id: 3,
    titulo: "Ritual del Maíz Sagrado",
    except: "Un menú dedicado al maíz en sus distintas variedaddes y preparaciones. Una celebración de uno de los cultivos más importantes del mundo andino.",
  },
];
