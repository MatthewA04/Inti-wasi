function Contacto() {
  return (
    <div>Contacto</div>
  )
}

export default Contacto