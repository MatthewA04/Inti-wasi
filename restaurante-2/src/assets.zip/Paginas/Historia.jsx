function Historia() {
  return (
    <div>Historia</div>
  )
}

export default Historia