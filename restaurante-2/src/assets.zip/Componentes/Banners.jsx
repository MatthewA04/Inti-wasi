import banner from "../Media/banner.png";

export default function Banners() {
  return <img className="banner" src={banner} alt="imagen de productos"></img>;
}
